package user.service;

import user.bean.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    public void save(User user) {
        //访问mysql
    }

    public void saveList(List<User> users) {

    }

}
