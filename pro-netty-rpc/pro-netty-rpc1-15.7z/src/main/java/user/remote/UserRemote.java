package user.remote;

import netty.util.Response;
import user.bean.User;

import java.util.List;

public interface UserRemote {

    Object saveUser(User user);

    Object saveUsers(List<User> users);
}
